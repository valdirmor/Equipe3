package br.com.itau.desafio.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.desafio.dao.HistoricoDAO;
import br.com.itau.desafio.model.Historico;

@RestController
@CrossOrigin("*")
public class HistoricoController {
	
	@Autowired
	private HistoricoDAO dao;
	
	@PostMapping("/historico/novo")
	public ResponseEntity<Historico> novoHistorico(@RequestBody Historico novo){
		try {
			dao.save(novo);
			return ResponseEntity.ok(novo);
		}catch(Exception e) {
			return ResponseEntity.status(400).build();
		}
	}
	
}
