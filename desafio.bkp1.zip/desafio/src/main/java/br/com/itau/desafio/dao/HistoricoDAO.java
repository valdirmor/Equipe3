package br.com.itau.desafio.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.itau.desafio.model.Historico;

public interface HistoricoDAO extends CrudRepository<Historico, Integer> {

	
}
