package br.com.itau.desafio.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.desafio.dao.ColaboradorDAO;
import br.com.itau.desafio.model.Colaborador;

@RestController
@CrossOrigin("*")
public class ColaboradorController {

	@Autowired
    private ColaboradorDAO dao;
	
	@GetMapping("/colaborador")
    public ResponseEntity<List<Colaborador>> getAll(){
        ArrayList<Colaborador> lista = (ArrayList<Colaborador>) dao.findAll();
        if (lista.size()>0) {
        
            return ResponseEntity.ok(lista);    
                
        }else {
            
            return ResponseEntity.status(403).build();
        }
    }
	
	 @GetMapping("/colaborador/{id}")
	    public ResponseEntity<Colaborador> getUserId(@PathVariable int id){
	        Colaborador resposta = dao.findById(id).orElse(null);
	        if (resposta != null) {
	            return ResponseEntity.ok(resposta);
	        
	        }else {
	            return ResponseEntity.notFound().build();
	        }
	    }
	
	    @PostMapping("/login")
	    public ResponseEntity<Colaborador> logar(@RequestBody Colaborador colaborador){
	        Colaborador u = dao.findByEmailAndSenha(colaborador.getEmail(), colaborador.getSenha());
	        if (u != null ) {
	            return ResponseEntity.ok(u);
	        }else {
	            return ResponseEntity.status(403).build();    
	            }
	    }
}
