function carregarUsuario(){
    var userString=localStorage.getItem("user");
    if (!userString){
        window.location="index2.html";
    }else {
        var user=JSON.parse(userString);
        document.getElementById("perfil").innerHTML=
        "<h4>" + "Colaborador: "+ user.nomeColab + "</h4>" +
        "<h4>" + "RACF: "+ user.racf + "<br>" +
        "<h4>" + "Email: "+ user.email + "<br>" +
        "<h4>" + "Departamento: "+ user.nomeDepart + "<br>" +
        "Conector:  " + user.numConectRede + "<br></h4>";

        document.getElementById("fotoUsuario").innerHTML=
        "<img src=imagens/"+user.foto+" width='20%'>"

    }
}