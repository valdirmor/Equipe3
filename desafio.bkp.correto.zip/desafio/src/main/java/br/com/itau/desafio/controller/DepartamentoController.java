package br.com.itau.desafio.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.desafio.dao.DepartamentoDAO;
import br.com.itau.desafio.model.Departamento;

@RestController
@CrossOrigin("*")
public class DepartamentoController {
	@Autowired
	private DepartamentoDAO dao;
	
	@GetMapping("/departamento")
	public ResponseEntity<List<Departamento>> getALL(){
		ArrayList<Departamento> lista = (ArrayList<Departamento>) dao.findAll();
		if (lista.size()!=0) {
			return ResponseEntity.ok(lista);
		}else {
			return ResponseEntity.status(403).build();
		}
	}
	
	@GetMapping("/departamento/{codigo}") 
	public ResponseEntity<Departamento> getDepartamentoCodigo(@PathVariable int codigo){
		Departamento resposta = dao.findById(codigo).orElse(null);
		if (resposta!=null) {
			return ResponseEntity.ok(resposta);
		}else {
			return ResponseEntity.status(403).build(); 
		}
		
	}
		
}
