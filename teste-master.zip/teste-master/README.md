# teste
Este é um repositório de teste,..

Clone do respositorio remotosdfsdfssdf

git clone <url>

git push (professor)

git pull (alunos)



